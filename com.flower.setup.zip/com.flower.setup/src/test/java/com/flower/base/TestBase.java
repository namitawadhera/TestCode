package com.flower.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class TestBase {
	public static String browser;
	public static WebDriver driver;
    public static String baseUrl ="https://www.bakewish.in/";
	
    public void setup() throws InterruptedException {
    	//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"C:/Floweraura/com.flower.setup/Drivers");
    	
    	System.setProperty("webdriver.chrome.driver","C:/Floweraura/com.flower.setup/Drivers/chromedriver.exe");
    	driver = new ChromeDriver();
    	launchURL();
    	
    }
	
 /*   public void TestBase(WebDriver driver) {
		this.driver = driver;
	}*/


	
	// Launching different browsers
	
	public void launchBrowser(String browser) {
		
		try {
			if (browser.equalsIgnoreCase("Chrome")) {
				driver = new ChromeDriver();
			}
		
		else if (browser.equalsIgnoreCase("Firefox")){
			driver = new FirefoxDriver();
		}
		else if (browser.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
			
		}
	}catch(WebDriverException e) {
		e.printStackTrace();
	}
	
	}
	
	//Implicit Wait
	
	public void setImplicitWait() {
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
	}
	
	// Explicit Wait
	
	public void setExplicitWait(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver,35);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		//wait.until(ExpectedConditions.elementToBeClickable(WebElement));
	}
	
	
	
	//Launch a URL
	
	   public void launchURL() throws InterruptedException {
		   driver.get("https://www.bakewish.in/");
		   Thread.sleep(500);
		   System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
	   }
	
	//Maximize Browser
	
	public void maximizeBrowser() throws InterruptedException {
		
		driver.manage().window().maximize();
		Thread.sleep(100);
	}
	
	//Clicking an element
	
	public void clickElement(WebElement e) {
		
		e.click();
	}
	
	//Element sorting by popularity
	
	public void popularitySort(WebElement popularitySort) {
	       popularitySort.click();
	
	}
	
	
	//Element sorting by lowToHigh
	
		public void lowToHighSort(WebElement lowToHigh) {
			lowToHigh.click();
		
		}
		
		//Element sorting by highToLow
		
		public void highToLowSort(WebElement highToLow) {
			highToLow.click();
		
		}

	// Function for vertical scroll down
		
		public void scrollDown() throws InterruptedException {
			((JavascriptExecutor) driver).executeScript("scroll(0,250);");
			Thread.sleep(1000);
			}
		
		
		// Function for vertical scroll up
		
				public void scrollUp() throws InterruptedException {
					((JavascriptExecutor) driver).executeScript("scroll(0,-250);");
					Thread.sleep(1000);
					}
				
		// Function for scrolling to an element of a page
				
				public void scrollToElement(WebElement element) {
					((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
                            ,element);
				}
				
				
		// Function to quit a browser
				
				public void quitBrowser() {
					driver.quit();
		
				}
				
			// Function for validating assert Equals
			
				public void assertEqualValidation(String expected, String actual) {
					 Assert.assertEquals(expected, actual); 
						
				}
				
				
				
		// Function for IsDisplayed
				
				public boolean display(WebElement element) {
					
					boolean result = element.isDisplayed();
					return result;
					
				}
				
		
			
				
				
				
				
	}




