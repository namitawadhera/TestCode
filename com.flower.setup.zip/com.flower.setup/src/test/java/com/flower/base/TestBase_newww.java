package com.flower.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import junit.framework.Assert;

public class TestBase_newww {
	public static String browser;
	public static WebDriver driver;
   
    public ExtentHtmlReporter htmlReporter;
    public ExtentReports extent;
    public ExtentTest test;
    
    //ReadPropertyFile data = new ReadPropertyFile()
        
    
    @BeforeSuite
    
    //Setting parameters for Extent Report
    public void setExtent() {
    	
    	htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/ExtentReport/MyReport.html");
    	htmlReporter.config().setDocumentTitle("Test Report");
    	htmlReporter.config().setReportName("Automation Testing");
    	htmlReporter.config().setTheme(Theme.STANDARD);
    	htmlReporter.config().setTimeStampFormat("hh/mm/ss");
    	
    	
    	extent = new ExtentReports();
    	extent.attachReporter(htmlReporter);
    	extent.setSystemInfo("OS","Windows");
    	extent.setSystemInfo("Project Name","Floweraura Automation" );
    	extent.setSystemInfo("Browser Name","Chrome" );
    	
    	
    	
    	
    }
	
    
    @AfterSuite
    
    public void endReport() {
    	
    	extent.flush();
    	
    }
    	
    /*	@AfterMethod
    	 public void endMethod(ITestResult result) throws IOException {
    	  if(result.getStatus()==ITestResult.FAILURE) {
    	   test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
    	   test.log(Status.FAIL, MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
    	   
    	   String pathString=TestBase.screenShot(driver, result.getName());
    	   test.addScreenCaptureFromPath(pathString);
    	   
    	  } else if(result.getStatus()==ITestResult.SKIP) {
    	   test.log(Status.SKIP, "Skipped Test case is: "+result.getName());
    	  } else if(result.getStatus()==ITestResult.SUCCESS) {
    	   test.log(Status.PASS, "Pass Test case is: "+result.getName());
    	  }
 
    	 } 	
    	
    	 public static String screenShot(WebDriver driver,String filename) {
    		  String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    		  TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
    		  File source = takesScreenshot.getScreenshotAs(OutputType.FILE);
    		  String destination = System.getProperty("user.dir")+"\\ScreenShot\\"+filename+"_"+dateName+".png";
    		  File finalDestination= new File(destination);
    		  try {
    		   FileUtils.copyFile(source, finalDestination);
    		  } catch (Exception e) {
    		   // TODO Auto-generated catch block
    		   e.getMessage();
    		  }
    		  return destination;
    		 }
    */
    public void setup() throws Exception {
    	//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"C:/Floweraura/com.flower.setup/Drivers");
    	
    	System.setProperty("webdriver.chrome.driver","C:/Floweraura/com.flower.setup/Drivers/chromedriver.exe");
    	driver = new ChromeDriver();
    	launchURL();
    	
    }
	
 

	
	// Launching different browsers
	
	public void launchBrowser(String browser) {
		
		try {
			if (browser.equalsIgnoreCase("Chrome")) {
				driver = new ChromeDriver();
			}
		
		else if (browser.equalsIgnoreCase("Firefox")){
			driver = new FirefoxDriver();
		}
		else if (browser.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
			
		}
	}catch(WebDriverException e) {
		e.printStackTrace();
	}
	
	}
	
	//Implicit Wait
	
	public void setImplicitWait() {
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
	}
	
	// Explicit Wait
	
	public void setExplicitWait(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver,35);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		//wait.until(ExpectedConditions.elementToBeClickable(WebElement));
	}
	
	
	
	//Launch a URL
	
	   public void launchURL() throws Exception {
		   driver.get("https://www.bakewish.in/");
		  // driver.get(prop.getProperty("baseURL"));
		   //driver.get(application.baseURL);
		   
		   /*ReadPropertyFile data = new ReadPropertyFile();
		   driver.get(data.getURL());
		   
		   //driver.get(pro.);*/
		   
		   Thread.sleep(500);
		   System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
	   }
	
	//Maximize Browser
	
	public void maximizeBrowser() throws InterruptedException {
		
		driver.manage().window().maximize();
		Thread.sleep(100);
	}
	
	
	
	
	// Selecting from dropdown
	
	public void selectElement(WebElement e2, int indexValue) {
	Select oselect = new Select(e2);
	//oselect.deselectByIndex(indexValue);
	oselect.selectByIndex(indexValue);
	}
	
	
	//Clicking an element
	
	
	
	public void clickElement(WebElement e) {
		
		e.click();
	}
	
	//Element sorting by popularity
	
	public void popularitySort(WebElement popularitySort) {
	       popularitySort.click();
	
	}
	
	
	//Element sorting by lowToHigh
	
		public void lowToHighSort(WebElement lowToHigh) {
			lowToHigh.click();
		
		}
		
		//Element sorting by highToLow
		
		public void highToLowSort(WebElement highToLow) {
			highToLow.click();
		
		}

	// Function for vertical scroll down
		
		public void scrollDown() throws InterruptedException {
			((JavascriptExecutor) driver).executeScript("scroll(0,250);");
			Thread.sleep(1000);
			}
		
		
		// Function for vertical scroll up
		
				public void scrollUp() throws InterruptedException {
					((JavascriptExecutor) driver).executeScript("scroll(0,-250);");
					Thread.sleep(1000);
					}
				
		// Function for scrolling to an element of a page
				
				public void scrollToElement(WebElement element) {
					((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
                            ,element);
				}
				
				
		// Function to quit a browser
				
				public void quitBrowser() {
					driver.quit();
		
				}
				
			// Function for validating assert Equals
			
				public void assertEqualValidation(String expected, String actual) {
					 Assert.assertEquals(expected, actual); 
						
				}
				
				
				
		// Function for IsDisplayed
				
				public boolean display(WebElement element) {
					
					boolean result = element.isDisplayed();
					return result;
					
				}
				
		// Random email generation
				
				public static String randomEmail() {
				String userName = ""+(int)(Math.random()*Integer.MAX_VALUE);
				String emailAddress = "User"+userName+"@gmail.com";
				System.out.println("Email address is::: "+emailAddress);
				    return emailAddress;
				}
			
		// Return OTP Value
				
				   public static String VerifyOTPInJsonResponse()
					{
					   
				
					   
					   String emailId= randomEmail();
					   String base_url="https://bakewishapis.bakewish.in/";
						String path="api/floweraura/fa/users/checkUser";
						String query="?user_email="+emailId;
						String url= base_url+path+query;
						
						System.out.println(url);
						RestAssured.get(url);
					   
					   
					
					 Response resp = RestAssured.get("https://bakewishapis.bakewish.in/api/fa/otp/get?phone=9643845584");
					 //  Response resp = RestAssured.get("https://bakewishapis.bakewish.in/api/fa/otp/get?email=&emailId");
					
					String data = resp.asString();
					
					System.out.println("Response in new format:::"+resp.prettyPrint());
					
					
					 // First get the JsonPath object instance from the Response interface
					 JsonPath jsonPathEvaluator = resp.jsonPath();
					 
					 Boolean successmsg = jsonPathEvaluator.get("success");
					 System.out.println("success msg received is::: " +successmsg);
					 
					 LinkedHashMap<String,Integer> hm = jsonPathEvaluator.get("data");
					 
					 
					 Collection<Integer> finalOTP = hm.values();
					 System.out.println("Key-Value pairs: "+hm.entrySet());
					 System.out.println("Values: "+hm.values()); 
					 
					 String otpValue = finalOTP.toString().substring(1, finalOTP.toString().length()-1);
					 
					 System.out.println(finalOTP.toString().substring(1, finalOTP.toString().length()-1));
					 System.out.println(otpValue);
					 return otpValue;
					 
					 
					}
					
					
				   //Function for Adding card details on Payment screen
				   
				   public void AddCardDetails() throws InterruptedException {
						  
						  
						Thread.sleep(4000);
						
					    WebElement cardNumber = driver.findElement(By.xpath("//*[@class=\"card_number_iframe\"]"));
						setExplicitWait(cardNumber);
						
						
					  System.out.println("User is on card number page");
					  cardNumber.click();
					  
					  cardNumber.sendKeys("5123456789012346");
					  
					 // driver.switchTo().parentFrame();
					  
					  
					  
					  //WebElement cardHolderName = driver.findElement(By.xpath("//*[@id=\"name_on_card\"]"));
					  WebElement cardHolderName = driver.findElement(By.xpath("//*[@class=\"name_on_card_iframe\"]"));
					  setExplicitWait(cardHolderName);
					  cardHolderName.click();
					  cardHolderName.sendKeys("demo test");
					  
				      //WebElement cardexpMonth = driver.findElement(By.xpath("//*[@id=\"card_exp_month\"]"));
					  WebElement cardexpMonth = driver.findElement(By.xpath("//*[@class=\"card_exp_month_iframe\"]"));
					  setExplicitWait(cardexpMonth);
					  
				      cardexpMonth.click();
				      cardexpMonth.sendKeys("05");
				      
				      
				      //WebElement cardExpYear = driver.findElement(By.xpath("//*[@id=\"card_exp_year\"]"));
				      WebElement cardExpYear = driver.findElement(By.xpath("//*[@class=\"card_exp_year_iframe\"]"));
				      setExplicitWait(cardExpYear);
				      cardExpYear.click();
				      cardExpYear.sendKeys("21");
					  
				     //WebElement cvv = driver.findElement(By.xpath("//*[@id=\"security_code\"]"));
				      WebElement cvv = driver.findElement(By.xpath("//*[@class=\"security_code_iframe\"]"));
				      setExplicitWait(cvv);
				      
				     cvv.click();
				     cvv.sendKeys("123");
				     
				     WebElement proceedButton = driver.findElement(By.xpath("//*[@id=\"edit-submit\"]"));
				     proceedButton.click();
				     
				     Thread.sleep(15000);
				     
				     
				  
					  
					  
				  }
				   
				   
				}
				
				
				
	




