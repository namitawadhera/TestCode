package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class RegisteredUserDeliveryAddress extends TestBase {
	
	
	public void validateHeader(WebElement header) {
		
		if(header.isDisplayed()==true) {
			
			System.out.println("you are on delivery address page");
		}
		
		else {
			System.out.println("you are NOT on delivery address page");
		}
	}
	
	
	public void newAddress(WebElement newAdd) {
		
		newAdd.click();
	}
	
	
	//Adding new address details again
	
	public void addAddressDetails(WebElement title,WebElement name, WebElement address, WebElement pincode, WebElement phoneNumber,
			WebElement addressType, WebElement continue2) 
			throws InterruptedException {
		  
		  
		  selectElement(title,2);
		  
		 //Locator for Name field
		  
		  
		  name.click();
		  name.clear();
		  name.sendKeys("ABC  XYZ");
		  
		  System.out.println("Name of the sender is:::"+name.getText());
		  
		  //Locator for Address 
		  
		  address.click();
		  address.sendKeys("House No#100, Sector-91, Gurgaon");
		  
		  // Locator for pincode
		  
		  pincode.clear();
		  pincode.sendKeys("122018");
		  Thread.sleep(3000);
	       
		 //Locator for Phone number
		  
		  phoneNumber.click();
		  phoneNumber.clear();
		  phoneNumber.sendKeys("9999999999");
		  
		  //Locator for Address type as Home
		  
		  
		  addressType.click();
		  
		  // Locator for Continue button
		  
		  
		  continue2.click();
	  }


}
