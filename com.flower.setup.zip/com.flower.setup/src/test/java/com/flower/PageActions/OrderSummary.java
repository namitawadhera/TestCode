package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class OrderSummary extends TestBase {
	
	public void validateCpnCode(WebElement couponCode1, WebElement couponText1, WebElement applyCoupon1) 
			throws InterruptedException {
		  
		  couponCode1.click();
		  
		  
		  couponText1.click();
		  couponText1.clear();
		  couponText1.sendKeys("FA10");
		  
		  //Click on Apply coupon link
		  
		  applyCoupon1.click();
		  Thread.sleep(2000);
	  }
	
	public void proceedToPaymentBtn(WebElement proceedBtn) throws InterruptedException {
		  
		  proceedBtn.click();
		  Thread.sleep(2000);
		  
	  }
	
	public void clickOnDeleteIcon(WebElement deleteBtn) {
		
		deleteBtn.click();
		
		
		
	}
	

}
