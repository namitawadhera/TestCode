package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class DeliveryDateAndTime extends TestBase {
	
	
	public void deliveryDateHeaderValidation(WebElement headerData) throws InterruptedException {
		  
		  
		   String headerValidateText = headerData.getText();
		   
		   if(headerValidateText.equalsIgnoreCase("Now Choose Delivery Date & Time")) {
			   
			   System.out.println("Select the slot you want to choose....");
		   }
		   
		   else {
			   System.out.println("You should be on delivery date section");
		   }

}
	
	public void tomorrowDate(WebElement date1) {
		
		setExplicitWait(date1);
		   date1.click();
	}
	
	//Function for selecting delivery slot mode as standard delivery
	   
	public void selectDeliverySlotMode(WebElement slotMode, WebElement slotTime)
	{
	
	   if(display(slotMode)==true) {
		   slotMode.click();
	   }
		   else {
			   System.out.println("Delivery slot not selected... please check");
		   }
	   
	   
		   
		 //Function for selecting delivery time slot
	   
	        slotTime.click();
	   
	   
	}
	
	public void clickContinueButton(WebElement continueBtn3) throws InterruptedException {
		
		continueBtn3.click();
		Thread.sleep(2000);
		
		
	}
	
	//function for validating special note functionality
	
	public void specialNote(WebElement headerNote, WebElement occassionSelect1) throws InterruptedException {
		
		String validatingspecialNoteHeadertext = headerNote.getText();
		System.out.println("Header name is::::"+validatingspecialNoteHeadertext);
		
		if(validatingspecialNoteHeadertext.equalsIgnoreCase("Show extra affection !")) {
			System.out.println("you can continue writing your text...");
			
		}
		
		else {
			System.out.println("stop.. you need to recheck your page");
		}
		
		Thread.sleep(1000);
		//Select first occassion in the list
		
		occassionSelect1.click();
}
	
	public void clickOnReview(WebElement reviewButton) throws InterruptedException {
		reviewButton.click();
		Thread.sleep(2000);
		
		}
	
	
	//Validate that user is on Next order Summary page
	
	public void validateOrderSummaryTitle(WebElement orderSummaryTitle1) {
	
	
	
	scrollToElement(orderSummaryTitle1);
	
	String orderSummaryTitleText = orderSummaryTitle1.getText();
	
	System.out.println("Title of Summary page is:::"+orderSummaryTitleText);
	
	if(orderSummaryTitleText.equalsIgnoreCase("Order Summary")) {
		System.out.println("You are on Order Summary page");
	}
	else {
		System.out.println("Checkout on which page you are...");
	}
}
	
	//complete future date selection for courier products
	public void courierDate(WebElement courierHeader, WebElement courierDate) {
		
		if(courierHeader.isDisplayed()== true) {
			
			System.out.println("Courier services present..");
			
			courierDate.click();
			
			
			
		}
		
		else {
			System.out.println("No courier product available for transaction");
		}
	}
}