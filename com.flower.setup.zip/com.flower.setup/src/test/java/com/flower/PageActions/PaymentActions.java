package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class PaymentActions extends TestBase{
	
	public void PAYU (WebElement paymentBtn) throws InterruptedException {
		
		paymentBtn.click();
		Thread.sleep(15000);
	}
	
	
	public void validatePaymentpageHeader(WebElement headerMsg1) throws InterruptedException {
		
		Thread.sleep(5000);
		String headerTitle = "Payment Method";
		
		String actualTitle = headerMsg1.getText();
		
		if(actualTitle.equalsIgnoreCase(headerTitle)) {
			System.out.println("User is on Payment page");
		}
		
		else {
			System.out.println("User is on different page");
		}
		//Thread.sleep(3000);
	}
	
	
	

}
