package com.flower.PageActions;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class CitySelectionActions extends TestBase {
	
	
	public void randomCitySelect(WebElement cityInput1, WebElement cityText1, List<WebElement> cityList1) throws InterruptedException {
		
		
		 
		  setExplicitWait(cityInput1);
		  
		  cityInput1.click();
		  Thread.sleep(7000);
		  
		  
		 
		  String textCity= cityText1.getText();
		  System.out.println("Heading is:::"+textCity);
		  
		  assertEqualValidation("Popular Cities", textCity);
		   
			 System.out.println("Popular cities dropdown is displayed");
			 
			 //List <WebElement> cityList1= driver.findElements(By.xpath("//*[contains(@class,'city-list')]//p"));
			 Thread.sleep(2000);
		
		  
			 
		
			  
			 
			 
			 WebElement num = getRandomElement(cityList1);
			 String text = num.getText();
			 Thread.sleep(1000);
			 System.out.println(text);
			  num.click();
		 }
			  
	  
	  public WebElement getRandomElement(List<WebElement> cityList1)
	    {
	        Random rand = new Random();
	        return cityList1.get(rand.nextInt(cityList1.size()));
	    }
}

