package com.flower.PageActions;

import java.util.Collection;
import java.util.LinkedHashMap;

import com.flower.base.TestBase;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class OTPScreen extends TestBase {
	
	
	
	 public static String VerifyOTPforRegisteredUser(String emailAddress)
		{
		   
		   String base_url="https://bakewishapis.bakewish.in/";
			String path="api/floweraura/fa/users/checkUser";
			String query="?user_email="+emailAddress;
			String url= base_url+path+query;
			
			System.out.println(url);
			RestAssured.get(url);
		   
		   
		  
		  String getPath = "api/fa/otp/get";
		  String getQuery= "?email="+emailAddress;
		  String getURL = base_url+getPath+getQuery;
		 Response resp = RestAssured.get("https://bakewishapis.bakewish.in/api/fa/otp/get?phone=9643845584");
		 // Response resp = RestAssured.get(getURL);
		  //System.out.println(getURL);
		
		String data = resp.asString();
		
		System.out.println("Response in new format:::"+resp.prettyPrint());
		
		
		 // First get the JsonPath object instance from the Response interface
		 JsonPath jsonPathEvaluator = resp.jsonPath();
		 
		 Boolean successmsg = jsonPathEvaluator.get("success");
		 System.out.println("success msg received is::: " +successmsg);
		 
		 LinkedHashMap<String,Integer> hm = jsonPathEvaluator.get("data");
		 
		 
		 Collection<Integer> finalOTP = hm.values();
		 System.out.println("Key-Value pairs: "+hm.entrySet());
		 System.out.println("Values: "+hm.values()); 
		 
		 String otpValue = finalOTP.toString().substring(1, finalOTP.toString().length()-1);
		 
		 System.out.println(finalOTP.toString().substring(1, finalOTP.toString().length()-1));
		 System.out.println(otpValue);
		 return otpValue;
		 
		 
		}
		
	
	
	

}
