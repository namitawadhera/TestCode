package com.flower.PageActions;

import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class ReviewDetailsScreen extends TestBase {
	
	
	public void validateReviewScreen(WebElement element) {
		
		if(element.isDisplayed()==true) {
			
			System.out.println("User is on Review Details screen");
		}
		
		else {
			
			System.out.println("Different screen");
		}
	}
	
	


}
