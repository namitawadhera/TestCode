package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class LoginAccount extends TestBase {

	
	
	
	
	
	public void registeredEmailID(WebElement emailId) throws InterruptedException {
		
		
		emailId.click();
		
		emailId.sendKeys("namitawadhera0410@gmail.com");
		Thread.sleep(1000);
		
	}
	
	
	// Click on COntinue Button
    
    public void clickContinueBtn(WebElement continueBtn) throws InterruptedException {
    continueBtn.click();
    Thread.sleep(2000);
    
    }
	
	//Function for clicking on Sign In button on homepage
    
    public void clickOnSignIN(WebElement signIn) {
    	
    	signIn.click();
    }
    
    
   

}
