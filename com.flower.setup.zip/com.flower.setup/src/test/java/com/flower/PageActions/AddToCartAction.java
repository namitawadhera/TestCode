package com.flower.PageActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.flower.base.TestBase;

public class AddToCartAction extends TestBase {
	
	
	 public void clickOnBuyButton(WebElement buyBtn) throws InterruptedException {
   	  
   	  
   	  Thread.sleep(2000);
   	  
   	  scrollToElement(buyBtn);
   	  System.out.println("Selecting buy now option");
   	 
   	     scrollUp();
         setExplicitWait(buyBtn);
         buyBtn.click();
         Thread.sleep(6000);
         
     }
	 
	 
	 public void displayViewMore(WebElement viewMore1, WebElement ratings1) throws InterruptedException {
		   
	    	 
	    	 scrollDown();
	    	 setExplicitWait(viewMore1);
	    	 Thread.sleep(2000);
	    	 
	    	if(viewMore1.isDisplayed()) {
	    		
	    		viewMore1.click();
	    		
	    		Thread.sleep(3000);
	    		
	    		String ratingsValue= ratings1.getText();
	    		   System.out.println("Ratings of the flower are:::"+ratingsValue);
	    		   Thread.sleep(3000);
	    		   driver.navigate().back();
	    		   Thread.sleep(1000);
	    	}
	    	
	    	else {
	    		
	    		System.out.println("No reviews are there for the flower.");
	    		
	    	}
	     }
	      
	 
	 
	

}
