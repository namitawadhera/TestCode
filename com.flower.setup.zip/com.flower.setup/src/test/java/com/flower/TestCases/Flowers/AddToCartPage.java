package com.flower.TestCases.Flowers;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.AddToCartAction;
import com.flower.base.TestBase;

public class AddToCartPage extends TestBase{
	
	AddToCartAction ac = new AddToCartAction();
	

	
	//Validate city name is displayed on location field on Add To Cart Page
  
	@Test(priority=132)
  public void cityValidation() {
	
	  
	  WebElement locationDisplayField = driver.findElement(By.xpath("//*[@class=\"pro-city-search\"]//input[1]"));
	  String locationValue = locationDisplayField.getAttribute("value");
	  
	  System.out.println("Location displayed on Add To Cart Page is:::"+locationValue);
	  
	  
  }
	
	
	
	
	
	@Test(priority=130)
	
	public void selectOptions() throws InterruptedException {
		
		WebElement flowerHeader= driver.findElement(By.xpath("//*[@class=\"discription-head\"]//h1"));
		scrollToElement(flowerHeader);
		
		try {
		
		
			WebElement doubleQty = driver.findElement(By.xpath("//*[text()=\"Double the flower quantity\"]"));
		
		if(doubleQty.isDisplayed()==true) {
			
			doubleQty.click();
			System.out.println("Double quantity clicked");
			
		}
		}
		catch (NoSuchElementException e){
			
			System.out.println("Exception occurred is:::"+e);
			
		}
		
		try {
	
			WebElement addVase = driver.findElement(By.xpath("//*[text()=\"Add Vase\"]"));
		
        if(addVase.isDisplayed()==true) {
			
        	addVase.click();
        	System.out.println("Add vase clicked");
			
		}
		}
		
		catch(NoSuchElementException e) {
			System.out.println("Exception occurred is:::"+e);
		}
		
		try {
		
			WebElement eggless = driver.findElement(By.xpath("//*[text()=\"Make it eggless\"]"));
		
        if(eggless.isDisplayed()==true) {
			
        	eggless.click();
        	System.out.println("Eggless checkbox clicked");
			//Thread.sleep(1000);
		}
	}
	
	catch(NoSuchElementException e) {
		System.out.println("Exception occurred is:::"+e);
	}
		
		try {
			
			WebElement addMoreRoses = driver.findElement(By.xpath("//*[text()=\"Add 10 red roses\"]"));
			
	        if(addMoreRoses.isDisplayed()==true) {
				
	        	addMoreRoses.click();
	        	System.out.println("more roses quantity clicked");
				Thread.sleep(1000);
			}
		}
		
		catch(NoSuchElementException e) {
			System.out.println("Exception occurred is:::"+e);
		}
		
	}
  
     
  
   @Test(priority=131)
     public void CakeMessage() throws InterruptedException {
	   
	  
	   Thread.sleep(2000);
  	 WebElement buyNowBtn = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
  	 scrollUp();
       //scrollToElement(buyNowBtn);
       if(display(buyNowBtn)== true) {
				
				System.out.println("User is on AddToCart Page");
				
			}
			
			else {
				
				System.out.println("User is on some different page... try again");
			}
  	 
  	 
		
		//Locator for msg print
		WebElement Message = driver.findElement(By.xpath("(//*[@id='edit-product-attribute-16'])[1]"));
		
		if(Message.isDisplayed()==true) {
		Message.click();
		Message.sendKeys("Happy birthday....");
		
		
		Thread.sleep(1000);
		}
		
		else {
			
			System.out.println("No message printed option available");
		}
 	
    	 }

	
     //Validate View More functionality of reviews
     
   //@Test(priority=131)
      public void displayViewMore1() throws InterruptedException {
	   
	   
    	 
    	 WebElement viewMore = driver.findElement(By.xpath("//*[text()=\"View More\"]"));
    	 
    	WebElement ratings = driver.findElement(By.xpath("//*[@class=\"rating-recommends-result\"][1]"));
    		   
    	ac.displayViewMore(viewMore, ratings);        
    		   
     }
      
    
      @Test(priority=134)
      
      public void validateProductDelivery() throws InterruptedException {
    	  
    	  WebElement deliverSuccessMsg = driver.findElement(By.xpath("//*[text()=\"Awesome we deliver to this location\"]"));
    	  WebElement buyNowButton = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
    	  
    	  if(deliverSuccessMsg.isDisplayed()==true) {
    		  
    		  
    		  ac.clickOnBuyButton(buyNowButton);
    		  
    	  }
    	  
    	  else {
    		  
    		  WebElement deliveryFailureMsg = driver.findElement(By.xpath("//*[contains(text(),'Sorry! we don’t')]"));
    		  
    		  if(deliveryFailureMsg.isDisplayed()==true)
    		  {
    			  
    			  WebElement areaPin = driver.findElement(By.xpath("//*[@name=\"areapin\"]"));
    			  areaPin.click();
    			  areaPin.clear();
    			  areaPin.sendKeys("Gurgaon");
    			  
    			  WebElement newCitySelect = driver.findElement(By.xpath("//*[@class=\"filter_City_Result\"]//li[1]"));
    			  newCitySelect.click();
    			  Thread.sleep(1000);
    			  ac.clickOnBuyButton(buyNowButton);
    			  
    		  }
    		  }
      }
      
      
     
     
          
     
      @Test(priority=129)
      public void validateCovidLink() throws Exception {
    	  
    	  //WebElement clickCovidLink = driver.findElement(By.xpath("//*[@class=\"covid-icon\"]"));
    	  WebElement clickCovidLink = driver.findElement(By.xpath("//*[text()=\"COVID-19 Measures taken by FA\"]"));
    	  setExplicitWait(clickCovidLink);
    	  
    	  if(clickCovidLink.isDisplayed()==true) {
    	  clickCovidLink.click();
    	  
    	  
    	  //calling function for covidlink from base class
    	  //clickonCovidLink(clickCovidLink);
    	  
    	  //validating video link
    	  WebElement videoLink = driver.findElement(By.xpath("//*[text()=\"Covid 19 Safety Measures Taken | FlowerAura\"]"));
    	  
    	  
    	  presenceOfVideoLink(videoLink);
      }
      }
}
