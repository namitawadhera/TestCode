package com.flower.TestCases.Flowers;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;

import java.util.Collection;
import java.util.LinkedHashMap;

//import io.restassured.matcher.RestAssuredMatchers.*;
import org.hamcrest.Matchers.*;


@SuppressWarnings("unused")
public class ResponseRead extends TestBase {

	public static String randomEmail() {
		String userName = ""+(int)(Math.random()*Integer.MAX_VALUE);
		String emailAddress = "User"+userName+"@gmail.com";
		System.out.println("Email address is::: "+emailAddress);
		    return emailAddress;
		}
	

     @Test
	public  String VerifyCityInJsonResponse()
	{
		
		String emailId= randomEmail();
	 //RestAssured.get("https://bakewishapis.bakewish.in/api/floweraura/fa/users/checkUser?user_email=namitawadhera0410@gmail.com");
		String base_url="https://bakewishapis.bakewish.in/";
		String path="api/floweraura/fa/users/checkUser";
		String query="?user_email="+emailId;
		String url= base_url+path+query;
		
		System.out.println(url);
		RestAssured.get(url);
		
		
	
	 Response resp = RestAssured.get("https://bakewishapis.bakewish.in/api/fa/otp/get?phone=9643845584");
		//Response resp = RestAssured.get("https://bakewishapis.bakewish.in/api/fa/otp/get?email=&emailId");
	
	String data = resp.asString();
	
	System.out.println("Response in new format:::"+resp.prettyPrint());
	
	
	 // First get the JsonPath object instance from the Response interface
	 JsonPath jsonPathEvaluator = resp.jsonPath();
	 
	 Boolean successmsg = jsonPathEvaluator.get("success");
	 System.out.println("success msg received is::: " +successmsg);
	 
	 LinkedHashMap<String,Integer> hm = jsonPathEvaluator.get("data");
	 
	 
	 Collection<Integer> finalOTP = hm.values();
	 System.out.println("Key-Value pairs: "+hm.entrySet());
	 System.out.println("Values: "+hm.values()); 
	 
	 String otpValue = finalOTP.toString().substring(1, finalOTP.toString().length()-1);
	 
	 System.out.println(finalOTP.toString().substring(1, finalOTP.toString().length()-1));
	 System.out.println(otpValue);
	 return otpValue;
	 
	 
	}
	
	
}
