package com.flower.TestCases;

public class RandomClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String userName = ""+(int)(Math.random()*Integer.MAX_VALUE);
		String emailAddress = "User"+userName+"@gmail.com";
		System.out.println("Email address is::: "+emailAddress);
		

	}

}
