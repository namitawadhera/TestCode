package com.flower.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class DeliveryAddress extends TestBase {
	
	
	//Add address details
	@Test (priority= 30)
  public void addAddressDetails() throws InterruptedException {
	  
	  //Locator for title dropdown
	  
	  WebElement title = driver.findElement(By.xpath("//*[@class=\"pincodewrap\"][1]"));
	  
	  selectElement(title,2);
	  
	 //Locator for Name field
	  
	  WebElement name= driver.findElement(By.xpath("//*[@id=\"name-field\"]"));
	  name.click();
	  name.clear();
	  name.sendKeys("ABC  XYZ");
	  
	  System.out.println("Name of the sender is:::"+name.getText());
	  
	  //Locator for Address 
	  
	  WebElement address = driver.findElement(By.xpath("//*[@class=\"input-area\"]"));
	  address.click();
	  address.sendKeys("House No#100, Sector-91, Gurgaon");
	  
	  // Locator for pincode
	  
	  WebElement pincode= driver.findElement(By.xpath("//*[@id=\"-field\"]"));
	  pincode.clear();
	  pincode.sendKeys("122018");
	  Thread.sleep(3000);
	  
	  //Locator for City
	  
	 /* WebElement city = driver.findElement(By.xpath("//*[@id=\"city-field\"]"));
	  city.clear();
	  city.sendKeys("Gurgaon");*/
       
	 //Locator for Phone number
	  
	  WebElement phoneNumber = driver.findElement(By.xpath("//*[@id=\"phone-field\"]"));
	  phoneNumber.click();
	  phoneNumber.clear();
	  phoneNumber.sendKeys("9999999999");
	  
	  //Locator for Address type as Home
	  
	  WebElement addressType = driver.findElement(By.xpath("//*[@class=\"address_type\"]//li[1]"));
	  addressType.click();
	  
	  // Locator for Continue button
	  
	  WebElement continue1 = driver.findElement(By.xpath("//*[@class=\"pry-btn\"]"));
	  continue1.click();
  }
}
