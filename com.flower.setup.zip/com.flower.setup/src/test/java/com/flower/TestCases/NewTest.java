package com.flower.TestCases;

import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class NewTest extends TestBase{
	
	
  @Test
  public void f() {
  }
}
