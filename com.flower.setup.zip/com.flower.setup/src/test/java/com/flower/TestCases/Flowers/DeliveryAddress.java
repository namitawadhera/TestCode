package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.RegisteredUserDeliveryAddress;
import com.flower.base.TestBase;

public class DeliveryAddress extends TestBase {
	
	RegisteredUserDeliveryAddress da = new RegisteredUserDeliveryAddress();
	
	
	//Add address details
	@Test (priority= 170)
  public void validateAddressDetails() throws InterruptedException {
		
		WebElement headerValidation = driver.findElement(By.xpath("//*[text()=\"Let us know where to deliver\"]"));
		
		da.validateHeader(headerValidation);
		
}
	
	@Test (priority= 171)
	public void addNewAddress() throws InterruptedException {
		
		WebElement newAddress = driver.findElement(By.xpath("//*[text()=\"Add Another Address\"]"));
		
		da.newAddress(newAddress);
		Thread.sleep(2000);
		
		
	}
	
	@Test (priority= 172)
	
	public void registernewAddress() throws InterruptedException {
		
		WebElement title1 = driver.findElement(By.xpath("//*[@class=\"pincodewrap\"][1]"));
		WebElement name1= driver.findElement(By.xpath("//*[@id=\"name-field\"]"));
		WebElement address1 = driver.findElement(By.xpath("//*[@class=\"input-area\"]"));
		WebElement pincode1= driver.findElement(By.xpath("//*[@id=\"-field\"]"));
		WebElement phoneNumber1 = driver.findElement(By.xpath("//*[@id=\"phone-field\"]"));
		WebElement addressType1 = driver.findElement(By.xpath("//*[@class=\"address_type\"]//li[1]"));
		WebElement continue1 = driver.findElement(By.xpath("//*[@class=\"pry-btn\"]"));
		
		da.addAddressDetails(title1, name1, address1, pincode1, phoneNumber1, addressType1, continue1);
	}
	
	
}
