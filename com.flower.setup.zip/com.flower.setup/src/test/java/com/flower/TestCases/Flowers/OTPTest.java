package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.LoginAccount;
import com.flower.PageActions.OTPScreen;
import com.flower.base.TestBase;



public class OTPTest extends TestBase {
	
	OTPScreen otpscreen = new OTPScreen();
	LoginAccount login = new LoginAccount();
	
	public static String email = "namitawadhera0410@gmail.com";	
	
	@Test(priority = 165)
  public void enterOTP() throws InterruptedException {
	  
	  
	  String otpID = OTPScreen.VerifyOTPforRegisteredUser(email);
	  
	  
	  WebElement OTPDetails = driver.findElement(By.xpath("//*[text()=\"Enter OTP\"]"));
	  OTPDetails.click();
	  OTPDetails.sendKeys(otpID);
	  Thread.sleep(2000);
	  
  //Click on Continue button
	  
	  WebElement cntBtn = driver.findElement(By.xpath("//*[text()=\"Enter OTP\"]"));
	  
	  login.clickContinueBtn(cntBtn);
	  Thread.sleep(2000);
	  
	  
  
  }
}
