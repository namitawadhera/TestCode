package com.flower.TestCases;

import java.util.stream.StreamSupport;
import java.util.stream.Stream;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;
import com.twilio.Twilio;
import com.twilio.base.ResourceSet;
import com.twilio.rest.api.v2010.account.Message;

public class LoginTest extends TestBase {
	
	
	
	@Test (priority= 21)
  public void Login() throws InterruptedException {
	  
		
		String userName = ""+(int)(Math.random()*Integer.MAX_VALUE);
		String emailAddress = "User"+userName+"@gmail.com";
		System.out.println("Email address is::: "+emailAddress);
		
	  //Login Details
      WebElement emailId =driver.findElement(By.xpath("(//input[@type='email'])[1]"));
      emailId.click();
      emailId.clear();
      
      emailId.sendKeys(emailAddress);
      
      // Click on COntinue Button
      
      WebElement continueBtn = driver.findElement(By.xpath("//*[@name='Continue']"));
      continueBtn.click();
      
      //Enter Details
      
      WebElement name = driver.findElement(By.xpath("//*[@id=\"name-field\"]"));
      setExplicitWait(name);
      
      name.sendKeys("abc000");
      
      WebElement phoneNumber = driver.findElement(By.xpath("//*[@id=\"mobile-field\"]"));
      setExplicitWait(phoneNumber);
      
      phoneNumber.sendKeys("9643845584");
      
      
      //Click on Continue button
      
      WebElement cntButton = driver.findElement(By.xpath("//*[@name=\"Continue\"]"));
      cntButton.click();
      
      
	}
      //Validate user is navigated to OTP screen
      
	@Test (priority= 22)
      
      public void validateOTP() throws InterruptedException {
      
      WebElement headerOTP = driver.findElement(By.xpath("//div[text()=\"Enter OTP\"]"));
      if(headerOTP.isDisplayed()) {
    	  System.out.println("User is navigated to the Enter OTP screen");
      }
      
      else {
    	  System.out.println("User is on incorrect page.. recheck");
      }
      
      //Calling function for entering OTP
      
      
      String OTPvalue;
      
      String otpvariable = VerifyOTPInJsonResponse();
     WebElement otpTextField = driver.findElement(By.xpath("//input[@id=\"otp-field\"]"));
     
     otpTextField.sendKeys(otpvariable);
      
      
      Thread.sleep(5000);
      continueBtn();
      
      }
     

	
	

  //Function for Resend OTP

    public void resendOTP() {
    	
        WebElement resendOTP = driver.findElement(By.xpath("//span[text()=\"Resend OTP\"]"));
        resendOTP.click();
        
    }
    
    //Function for clicking Continue button
    
    public void continueBtn() throws InterruptedException {
    	WebElement continueButton = driver.findElement(By.xpath("//*[@name=\"Continue\"]"));
    	continueButton.click();
    	System.out.println("User is able to login");
    	Thread.sleep(2000);
    }
    
    
    @Test (priority= 23)
    
    public void reviewDetails() {
    	
    	driver.findElement(By.xpath("//*[@class=\"pry-btn\"]")).click();
    }
    
   
   
}

