package com.flower.TestCases.Flowers;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.LoginAccount;
import com.flower.base.TestBase;

public class LoginTest extends TestBase {
	
	
	//Creating instance for LoginAccount class
	
	LoginAccount login = new LoginAccount();
	
	
	@Test(priority =1)
	  
	  public void launchApplication() throws Exception {
		  
		 
		 setup();
		  
		  maximizeBrowser();
		  Thread.sleep(8000);
	  }	
	
  @Test (priority = 2)
  public void Login() {
	  
	  WebElement signInBtn = driver.findElement(By.xpath("//*[text()=\"Sign In\"]"));
	  
	  login.clickOnSignIN(signInBtn);
	  
  }

 //@Test (priority = 3)
// Entering registered email id
  
  
  public void windowSwitch() throws InterruptedException {
	  
	  String mainWinHander = driver.getWindowHandle();
	  System.out.println(mainWinHander);

	
	Set<String> handles = driver.getWindowHandles();
	System.out.println("Handlers present:::"+handles.size());

	for(String handle : handles)
	{
	    if(!mainWinHander.equals(handle))
	    {
	        // Here will block for ever. No exception and timeout!
	        driver.switchTo().window(handle);
	        System.out.println("Window switched");
	        
	        enterRegisteredEmailID();
	        
	        System.out.println("closed");
	    }
	    
	    else {
	    	System.out.println("no handlers");
	    }
	    
	    WebElement registeredemailID = driver.findElement(By.xpath("//*[@class=\"floating-label\"]"));
		setExplicitWait(registeredemailID);
		
		registeredemailID.click();
		registeredemailID.sendKeys("namitawadhera0410@gmail.com");
	}
  }
  
  
  @Test (priority = 3)
public void enterRegisteredEmailID() throws InterruptedException {
	
	  //driver.switchTo().window(arg0);
	  
	  WebElement hellotext= driver.findElement(By.xpath("//div//h2[text()=\"Hello!\"]"));
	  
	  
	  //driver.switchTo().alert();
	  System.out.println("hello123");
	  
	  WebElement header = driver.findElement(By.xpath("//*[text()=\"Please Enter your email \"]"));
	  
	  if(header.isDisplayed()==true)
		  
	  {
		  System.out.println("user is on page");
		  
	  }
	  else {
		  System.out.println("user is on different page");
	  }
		  
		  
		  //WebElement registeredemailID = driver.findElement(By.xpath("//*[text()=\"Email\"]"));
	 // WebElement registeredemailID = driver.findElement(By.xpath("//*[@class=\"form-field\"]//input"));
	WebElement registeredemailID = driver.findElement(By.xpath("//*[@class=\"floating-label\"]"));
	setExplicitWait(registeredemailID);
	
	registeredemailID.click();
	registeredemailID.sendKeys("namitawadhera0410@gmail.com");
	//login.registeredEmailID(registeredemailID);
	
	WebElement continueBtnClick = driver.findElement(By.xpath("//*[@value=\"CONTINUE\"]"));
	login.clickContinueBtn(continueBtnClick);
	
	
	
	

	
}
  
  




}