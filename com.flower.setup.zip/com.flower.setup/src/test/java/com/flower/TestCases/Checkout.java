package com.flower.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class Checkout extends TestBase{
  
	
	
	
	
	@Test (priority= 33)
  public void deliveryDate() throws InterruptedException {
	  
	  WebElement headerValidate = driver.findElement(By.xpath("//*[text()=\"Now Choose Delivery Date & Time\"]"));
	   String headerValidateText = headerValidate.getText();
	   
	   if(headerValidateText.equalsIgnoreCase("Now Choose Delivery Date & Time")) {
		   
		   System.out.println("Select the slot you want to choose....");
	   }
	   
	   else {
		   System.out.println("You should be on delivery date section");
	   }
	   
	   
	   WebElement date = driver.findElement(By.xpath("//*[@class=\"del-date-inner\"]//li[2]"));
	   setExplicitWait(date);
	   date.click();
	   
	   //Function for selecting delivery slot mode as standard delivery
	   
	   WebElement deliverySlotMode = driver.findElement(By.xpath("//*[@value=\"Standard Delivery\"]"));
	   if(display(deliverySlotMode)==true) {
		   deliverySlotMode.click();
	   }
		   else {
			   System.out.println("Delivery slot not selected... please check");
		   }
		   
		 //Function for selecting delivery time slot
	   
	   WebElement deliverySlotTime = driver.findElement(By.xpath("//*[@class=\"fix-time-slot\"]//li[2]//input"));
	   deliverySlotTime.click();
	   
	   
	   
	   WebElement clickContinue = driver.findElement(By.xpath("//*[@value=\"Continue\"]"));
	   clickContinue.click();
	   
	   Thread.sleep(2000);
	   
	   //calling specialNote function
	   
	   specialNote();
	   
	   
	  
  }
	
	
	//Function for validating special note
	
	public void specialNote() throws InterruptedException {
		WebElement validatingspecialNoteHeader = driver.findElement(By.xpath("//span[text()=\"Show extra affection ! \"]"));
		String validatingspecialNoteHeadertext = validatingspecialNoteHeader.getText();
		System.out.println("Header name is::::"+validatingspecialNoteHeadertext);
		
		if(validatingspecialNoteHeadertext.equalsIgnoreCase("Show extra affection !")) {
			System.out.println("you can continue writing your text...");
			
		}
		
		else {
			System.out.println("stop.. you need to recheck your page");
		}
		
		//Select first occassion in the list
		
		WebElement occassionSelect = driver.findElement(By.xpath("//*[@class=\"del-date-inner\"]//li[1]"));
		occassionSelect.click();
		
		//Clicking on Review button
		
		WebElement reviewBtn = driver.findElement(By.xpath("//*[@value=\"Review\"]"));
		reviewBtn.click();
		Thread.sleep(2000);
		
		//Validate that user is on Next order Summary page
		
		WebElement orderSummaryTitle= driver.findElement(By.xpath("//span[text()=\"Order Summary\"]"));
		
		scrollToElement(orderSummaryTitle);
		
		String orderSummaryTitleText = orderSummaryTitle.getText();
		
		System.out.println("Title of Summary page is:::"+orderSummaryTitleText);
		
		if(orderSummaryTitleText.equalsIgnoreCase("Order Summary")) {
			System.out.println("You are on Order Summary page");
		}
		else {
			System.out.println("Checkout on which page you are...");
		}
	}
	
	
	
	
	
}
