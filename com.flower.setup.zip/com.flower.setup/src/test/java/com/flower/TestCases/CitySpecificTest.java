package com.flower.TestCases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.flower.base.TestBase;

public class CitySpecificTest extends TestBase {
	  
	  //Locator for Blackforest cake
	  
	  @FindBy (xpath="//*[@class=\"slideupdown-category birthday-gifts\"]//../a")
	  WebElement blackForestCake;
	  
	  
	  //Function to click on Cakes (Blackforest cake
	  
	 @Test(priority=3) 
	public void navigateToCakes() throws InterruptedException {
		 
		// test=extent.createTest("navigateToCakes");
	
		 Thread.sleep(2000);
		 Actions actions = new Actions(driver);
		
		WebElement expressDelivery = driver.findElement(By.xpath("//*[text()=\"Express Delivery\"]"));
		actions.moveToElement(expressDelivery).build().perform();
		
		//System.out.println("pass1");
		
	
		WebElement cakes = driver.findElement(By.xpath("//a[@href=\"/cakes\"][1]"));
	System.out.println("pass2");
	setExplicitWait(cakes);
	cakes.click();
	
	//System.out.println("pass3");
		  
		  
		  WebElement cakesHeader = driver.findElement(By.xpath("//*[@class=\"js-page-banner\"]/h1"));
		  
		 // System.out.println("pass4");
		  setExplicitWait(cakesHeader);
		  String text= cakesHeader.getText();
		  //System.out.println("pass5");
		  
		 
		  Assert.assertEquals("Online Cake Delivery In India", text);
				 System.out.println("Message is displayed correctly");
			
			
				 WebElement cakeflavour= driver.findElement(By.xpath("//*[@class=\"slideupdown-category birthday-gifts\"]/h2"));
				 scrollToElement(cakeflavour);
				 
				 String textvalidate = cakeflavour.getText();
				 System.out.println(textvalidate);
				 
	  
	  }
      
	@Test(priority=4)
	  public void clickOnCake() throws InterruptedException {
		
	//	test=extent.createTest("clickOnCake");
		  
		  //Locator for finding list of number of cakes present by flavour
		  
		  List<WebElement> cakeList = driver.findElements(By.xpath("//*[@class=\"slideupdown\"]//a"));
		 
		  String randomSelection = "Cake ABC";
		  String cakeFlavourSelect = "Black Forest";
		  Thread.sleep(3000);
		  
          for (WebElement we : cakeList) {
        	  System.out.println("name of cakes present on same page::: "+we.getText());
        	  if(we.getText().equalsIgnoreCase(randomSelection)) {
        		  
        		  clickElement(we);
        	  }
        	  
        	  else {
        		  System.out.println("Selected cake::" +randomSelection+ "is NOT present at the selected location");
        	  }
			  if(we.getText().equalsIgnoreCase(cakeFlavourSelect)) {
				  
				  //If Blackforest cake is found then click on it
			    clickElement(we);
			    
			    System.out.println("pass6");
			    Thread.sleep(1000);
			    
			    WebElement popularIcon = driver.findElement(By.xpath("//*[text()=\"Popularity\"]"));
				if(display(popularIcon)==true) {
					
					System.out.println("User is on Cake Specific page");
				}
				
				else {
					System.out.println("User is on different page. Navigate to cake specific page");
				}
          
	
			 
          System.out.println("finished tc");    
          
	  }
          }
	}
}
	


