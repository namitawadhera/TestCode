package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.LoginAccount;
import com.flower.base.TestBase;

public class RegisteredUserLoginTest extends TestBase {
	
	
	LoginAccount login = new LoginAccount();
  @Test (priority=160)
  public void validateLogin() throws InterruptedException {
	  
	  WebElement emailId1 =driver.findElement(By.xpath("(//input[@type='email'])[1]"));
	  
	  login.registeredEmailID(emailId1);
	  
	  System.out.println("Email id is entered successfully");
	  
	  
  }
  
  @Test (priority=161)
  
  public void clickContinue() throws InterruptedException {
	  WebElement continueBtn1 = driver.findElement(By.xpath("//*[@name='Continue']"));
	  
	  login.clickContinueBtn(continueBtn1);
  }
}
