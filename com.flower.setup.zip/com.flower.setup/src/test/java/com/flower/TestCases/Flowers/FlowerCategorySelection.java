package com.flower.TestCases.Flowers;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class FlowerCategorySelection extends TestBase {
	
	
	@Test (priority=110)
	  public void FlowersList() throws InterruptedException {
		  
		  List<WebElement> flowerTypes = driver.findElements(By.xpath("//*[@id=\"category-slider\"]//li"));
		  
		 //Printing all elements in a list
		  
		  Iterator<WebElement> itr = flowerTypes.iterator();
		  while(itr.hasNext()) {
			  String values = itr.next().getText();
			  
		      //System.out.println("Types of flowers present are::: "+values);
		      
		      if(values.equalsIgnoreCase("ABC flower")) {
		    	  System.out.println("ABC flower is present");
		      }
		      
		      else {
		    	  System.out.println("ABC flower is NOT present");
		    	  
		      }
		      
		  }
	}
		      
		     //Selecting Flower and Cake category
		      
		      @Test(priority=111)
		      public void userSelection() throws InterruptedException {
		    	  
		    	  List<WebElement> flowerTypes1 = driver.findElements(By.xpath("//*[@id=\"category-slider\"]//li"));
		    	  System.out.println(flowerTypes1.size());
		    	  

					 WebElement categorySelection = getRandomElement(flowerTypes1);
					 Thread.sleep(1000);
					 
					 for(WebElement w : flowerTypes1)
					 
					 {
					 
					 if(categorySelection.isDisplayed()==true) {
					 
					 String flowerCategoryName = categorySelection.getText();
					 System.out.println("Flower Category Product chosen is:::"+flowerCategoryName);
					 categorySelection.click();
					 Thread.sleep(2000); 
					 break;
					 
					 
					 }
					 
					 else {
						 WebElement nextBtn= driver.findElement(By.xpath("//*[@class=\"arrow-right-icon\"]"));
						 nextBtn.click();
						 if(categorySelection.isDisplayed()==true) {
							 categorySelection.click();
						 }
						 
						 else {
							 nextBtn.click();

				    	  categorySelection.click();
						 }
					 }
		    	  
					 }
		    	  
		    	//Commenting below code and writing code for selecting any random flower category
		    /*List<WebElement> flowerTypes1 = driver.findElements(By.xpath("//*[@id=\"category-slider\"]//li"));
		      for ( WebElement flowerCategory: flowerTypes1) { 
		    	  
		    	  WebElement nextBtn= driver.findElement(By.xpath("//*[@class=\"arrow-right-icon\"]"));
		    	  nextBtn.click();
		    	  
		    	  System.out.println("Next button is clicked");
		    	  
		    	  
					
		    	  WebElement flowerSelected = driver.findElement(By.xpath("//*[text()=\"Flower and Cake\"]"));
		    	  setExplicitWait(flowerSelected);
		    	  String selectFlower = flowerSelected.getText();
		    	  
		    	 System.out.println("Flower user selected is::::"+selectFlower);
		    	  
		    	  String flowerText = "Flower and Cake";
		    	  
		    	  if(flowerText.equalsIgnoreCase(selectFlower)) {
		    		  flowerSelected.click();
		    		  System.out.println("clicked");
		    		  break;
		    	  }
		    	  
		    	  System.out.println("User selected category is clicked");
		    	 Thread.sleep(2000); */
		    	  
		    	  
		    	  
		    	  
					
			}

		      
		    
		      }
		  
		  
		  
		  
		  
		  
	 
	

