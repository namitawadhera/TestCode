package com.flower.TestCases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class AddToCartPage extends TestBase{
	
	
	
	
	
	
	//Validate Gurgaon city is displayed on location field on Add To Cart Page
  
	@Test(priority=9)
  public void validateCity() {
		
		//test=extent.createTest("validateCity");
	  
	  WebElement locationDisplayField = driver.findElement(By.xpath("//*[@class=\"pro-city-search\"]//input[1]"));
	  String locationValue = locationDisplayField.getAttribute("value");
	  
	  System.out.println("Location displayed on Add To Cart Page is:::"+locationValue);
	  
	  if(locationValue.equalsIgnoreCase("Gurgaon")) {
		  System.out.println("City is displayed correctly as:::"+locationValue);
	  }
	  
	  else {
		  System.out.println("Incorrect city is displayed... Kindly validate");
	  }
  }
  
      //Click on 1 kg weight
  
   @Test(priority=8)
     public void selectcakeWeight() throws InterruptedException {
	   
	  // test=extent.createTest("selectcakeWeight");
    	 
    	 Thread.sleep(2000);
    	 WebElement buyNowBtn = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
    	 scrollUp();
         //scrollToElement(buyNowBtn);
         if(display(buyNowBtn)== true) {
				
				System.out.println("User is on AddToCart Page");
				
			}
			
			else {
				
				System.out.println("User is on some different page... try again");
			}
    	 
    	 driver.findElement(By.xpath("(//ul[@id='edit-product-attribute-10']/li)[2]")).click();
    	 
    	 System.out.println("hello2");
    	 
    	 //scrollToElement(cakeWeight);
    	 
    	  
    	 System.out.println("1 kg weight is selected");
    	 
    	
    	 //Locator for checkbox
    	 
    	 driver.findElement(By.xpath("//span[@class='checkmark'][1]")).click();
 		System.out.println("Checkbox is clicked");
 		
 		//Locator for msg print
 		WebElement Message = driver.findElement(By.xpath("(//*[@id='edit-product-attribute-16'])[1]"));
 		Message.click();
 		Message.sendKeys("Happy birthday....");
 		
 		//Locator for Buy now button
 		
 		//WebElement buttonClick= driver.findElement(By.xpath("//*[text()=\"BUY NOW\"]"));
 		Thread.sleep(1000);
 		//buyNowBtn.click();
  	    //System.out.println("Selecting buy now option");
  	    //buttonClick.click();
 	
    	 }

	
     //Validate View More functionality of reviews
     
   //@Test(priority=7)
      public void displayViewMore() throws InterruptedException {
	   
	   //test=extent.createTest("displayViewMore");
    	 
    	 WebElement viewMore = driver.findElement(By.xpath("//a[text()='View More']"));
    	 scrollDown();
    	 //scrollToElement(viewMore);
    	 setExplicitWait(viewMore);
    	 Thread.sleep(2000);
    	 
    	if(viewMore.isDisplayed()) {
    		
    		viewMore.click();
    		
    		Thread.sleep(3000);
    		WebElement giftCityHeader= driver.findElement(By.xpath("//*[@class=\"popular-cities\"]//h2[1]"));
    		
    		  /* if(giftCityHeader.isDisplayed()) {
    			   WebElement closeBtn= driver.findElement(By.xpath("//*[@class=\"close-btn\"]"));
    			   closeBtn.click();
    			   System.out.println("City popup msg is closed");
    		   }
    		   else {
    			   
    			   System.out.println("No popup msg present");
    		   }*/
    		
    		   WebElement ratings = driver.findElement(By.xpath("//*[@class=\"rating-recommends-result\"][1]"));
    		   
    		   String ratingsValue= ratings.getText();
    		   System.out.println("Ratings of the cake are:::"+ratingsValue);
    		   Thread.sleep(3000);
    		   driver.navigate().back();
    		   Thread.sleep(1000);
    	}
    	
    	else {
    		
    		System.out.println("No reviews are there for the cake.");
    		
    	}
     }
      
     
     
      @Test (priority=10)
          public void clickOnBuyButton() throws InterruptedException {
    	  
    	 // test=extent.createTest("clickOnBuyButton");
        	  
        	  Thread.sleep(2000);
        	  //WebElement buyNowButton = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
        	  
        	  /*String mainWindow = driver.getWindowHandle();
        	  
        	  Alert a1 = driver.switchTo().alert();
              a1.dismiss();
              
              driver.switchTo().window(mainWindow);*/
        	  WebElement buyNowButton = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
        	  scrollToElement(buyNowButton);
        	  System.out.println("Selecting buy now option");
        	 
        	  scrollUp();
              //scrollToElement(buyNowButton);
              setExplicitWait(buyNowButton);
              buyNowButton.click();
              Thread.sleep(2000);
              
          }
     
     
}
