package com.flower.TestCases.Flowers;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;
import com.google.common.base.CharMatcher;

public class FlowerSelection extends TestBase {
  
	
	// Validate that filter icon is present
			
	
	@Test (priority=120)
			public void validatePopularityIcon() {
				
								
				//Locator for Popularity Button
				WebElement popularIcon = driver.findElement(By.xpath("//*[text()=\"Popularity\"]"));
				if(display(popularIcon)==true) {
					
					System.out.println("User is on Flower Specific page");
				}
				
				else {
					System.out.println("User is on different page. Navigate to flower specific page");
				}
			}
			
			
			//Printing all flowers present on a page
			
	@Test (priority=121)
			
			public void PrintFlowerList() {
			List<WebElement> flowersPresent = driver.findElements(By.xpath("//*[contains(@class,'prod-detail-wrap')]//a"));
			System.out.println("Number of flowers present on page are::"+flowersPresent.size());
			
			//Printing all elements in a list
			
			Iterator <WebElement> itr = flowersPresent.iterator();
			
			while(itr.hasNext()) {
				String values = itr.next().getText();
				System.out.println(values);
			
			}
			}
			
			
			// Clicking on first flower
	@Test (priority=122)
			
			public void clickOnFlower() throws InterruptedException {
				
				List<WebElement> flowersPresent1 = driver.findElements(By.xpath("//*[contains(@class,'prod-detail-wrap')]//a"));
                for ( WebElement client: flowersPresent1) { 
					
					System.out.println("name of flower selected::: "+client.getText());
					//String flowerName= client.getText();
					WebElement price = driver.findElement(By.xpath("//*[@class=\"flt price\"][1]"));
					
					String priceTag= price.getText();
					System.out.println("Price of the flower is:::"+priceTag);
					String mainWindowHandle = driver.getWindowHandle();

			         client.click();
			         break;
			}
                
                Set<String> allWindowHandles = driver.getWindowHandles();
		        Iterator<String> iterator = allWindowHandles.iterator();
				
		        while (iterator.hasNext()) {
		            String ChildWindow = iterator.next();
		                driver.switchTo().window(ChildWindow);
		                Thread.sleep(5000);
		                addToCartPage();
		                
                         //validate cart page details are same
		                
		                validateFlowerDetails();

				
			}
		      
		        
			}     
			
			
			public void addToCartPage() throws InterruptedException {
				
				//Get handles of all windows
					
				
		                
		              //Locator for Buy Now button
		                System.out.println("Add to cart page is displayed");
		                
		         
		                
		                WebElement buyNowBtn = driver.findElement(By.xpath("//*[@id=\"addToCart\"]/div[2]/a[1]"));
		                scrollToElement(buyNowBtn);
		                if(display(buyNowBtn)== true) {
		    				
		    				System.out.println("User is on AddToCart Page");
		    			}
		    			
		    			else {
		    				
		    				System.out.println("User is on some different page... try again");
		    			}
		            }
		        
		        public void validateFlowerDetails() {
					
		        	//Print Name and price from Add To Cart screen
		        	
					 WebElement flowerHeader= driver.findElement(By.xpath("//*[@class=\"discription-head\"]//h1"));
		             System.out.println("Name of flower on Add to cart page is:::"+flowerHeader.getText());
		             
		             WebElement priceHeader= driver.findElement(By.xpath("//*[@class=\"discription-head\"]//*[@class=\"priceNumber\"]"));
		             String priceValue = priceHeader.getText();
		             System.out.println("Price is:::"+priceValue);
		             System.out.println(CharMatcher.digit().retainFrom(priceValue));
					
				}
			    
				
			
			
}
