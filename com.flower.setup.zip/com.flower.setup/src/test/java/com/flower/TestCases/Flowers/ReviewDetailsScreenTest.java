package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.flower.PageActions.ReviewDetailsScreen;
import com.flower.base.TestBase;

public class ReviewDetailsScreenTest extends TestBase {
	
	ReviewDetailsScreen review = new ReviewDetailsScreen();
	
	
  @Test (priority = 168)
  public void validateHeader() {
	  WebElement headerText = driver.findElement(By.xpath("//*[text()=\"Let us know you better\"]"));
	  String headercontent = headerText.getText();
	  
	  review.validateReviewScreen(headerText);
	  
	  
  }
  
  @Test (priority = 169)
  public void clickButton() throws InterruptedException {
	  
	  WebElement clickElement = driver.findElement(By.xpath("//*[@name=\"Continue\"]"));
	  
	  //calling click element function from testBase class
	  
	  clickCntBtn(clickElement);
	  Thread.sleep(3000);
	  
	  
  }
  
  
  
}
