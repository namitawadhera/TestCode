package com.flower.TestCases.Flowers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.OrderSummary;
import com.flower.base.TestBase;

public class OrderSummaryTest extends TestBase {
	
	OrderSummary os = new OrderSummary();
	
	
	@Test (priority= 190)
  public void validateCouponCode() throws InterruptedException {
	  
	  WebElement couponCode = driver.findElement(By.xpath("//*[@class=\"coupon-show-click\"]"));
	  	  
	  WebElement couponText = driver.findElement(By.xpath("//*[@id=\"coupon-wrap\"]"));
	  
	  WebElement applyCoupon = driver.findElement(By.xpath("//*[@class=\"apply-link\"]"));
	  
	  os.validateCpnCode(couponCode, couponText, applyCoupon);
	  
  }
	
	
	@Test (priority= 191)
  
  public void proceedToPayment() throws InterruptedException {
	  
	  WebElement paymentBtn = driver.findElement(By.xpath("//input[@name=\"Proceed to payment\"]"));
	  
	  os.proceedToPaymentBtn(paymentBtn);
	  Thread.sleep(2000);
	  
  }
	
	//List<WebElement> deleteIcon = driver.findElements(By.xpath("//*[@class=\"pro-name\"]//span"));
	
	
}
