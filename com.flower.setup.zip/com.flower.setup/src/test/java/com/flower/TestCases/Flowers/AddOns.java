package com.flower.TestCases.Flowers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class AddOns extends TestBase{
  
	
	@Test(priority=141)
  public void clickOnAddOns() throws InterruptedException {
		
		
	  
		setImplicitWait();
		
	 try {
		
		WebElement magiccandle= driver.findElement(By.xpath("//*[@id=\"product-addon-add-24819\"][1]"));
	  magiccandle.click();
	  System.out.println("candles selected....");
	  Thread.sleep(1000);
	  
	 
	  //Validate the msg displayed at bottom
	  
	  WebElement msgDisplayAtBottom = driver.findElement(By.xpath("//*[@class=\"addon-count\"]"));
	  String msg = msgDisplayAtBottom.getText();
	  System.out.println("Msg is displayed as:::"+msg);
	  
	  WebElement downArrow = driver.findElement(By.xpath("//*[@class=\"addon-count-desktop\"]//span"));
	  
	  downArrow.click();
	  
}
	 
	 catch(NoSuchElementException e) {
		 System.out.println("no magic candles selected..");
	 }
	 
	 
	  WebElement continueBtn = driver.findElement(By.xpath("//*[@id=\"addon-form-submit\"]"));
	  continueBtn.click();
	  
	  System.out.println("User is directed to payment page");
	  Thread.sleep(3000);
	  
	  WebElement myCart = driver.findElement(By.xpath("//*[text()=\"My Cart\"]"));
	  String welcomeHeader = myCart.getText();
	  
	  if(welcomeHeader.equalsIgnoreCase("My Cart")) {
		  System.out.println("User is on My Cart Page");
	  }
	  
	  
	  else {
		  System.out.println("User is on different page");	  }
	       }
}
