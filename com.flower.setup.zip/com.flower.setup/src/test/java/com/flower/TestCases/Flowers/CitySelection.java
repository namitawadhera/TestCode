package com.flower.TestCases.Flowers;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.flower.base.TestBase;
import com.flower.base.TestBase_newww;

public class CitySelection extends TestBase{
	
	 
		
	
	  
	
    //Method for selecting city from popup
	 
	  
	  
	  @Test(priority=20)
	  public void selectCity() throws InterruptedException {
		  
		  
		  
		  WebElement cityInput = driver.findElement(By.xpath("//*[@id='user-selected-city-input']"));
		 
		  setExplicitWait(cityInput);
		  
		  cityInput.click();
		  Thread.sleep(7000);
		  
		  WebElement cityText = driver.findElement(By.xpath("//*[text()='Popular Cities']"));
		 
		  String textCity= cityText.getText();
		  System.out.println("Heading is:::"+textCity);
		  
		  assertEqualValidation("Popular Cities", textCity);
		   
			 System.out.println("Popular cities dropdown is displayed");
			 
			 WebElement citySelection = driver.findElement(By.xpath("//*[@name=\"select_city\"]"));
			 
			 setExplicitWait(citySelection);
			 citySelection.click();
			 citySelection.sendKeys("Ujjain");
			 WebElement cityDropdown = driver.findElement(By.xpath("//*[@class=\"filter_City_Result\"]"));
			 cityDropdown.click();
			
			 Thread.sleep(1000);
			  }
}

