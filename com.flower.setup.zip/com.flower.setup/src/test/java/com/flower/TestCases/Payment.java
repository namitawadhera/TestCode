package com.flower.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class Payment extends TestBase {
	
	
	
	@Test (priority= 40)
	
	public void validatePaymentpage() throws InterruptedException {
	
		Thread.sleep(5000);
		String headerTitle = "Payment Method";
		WebElement headerMsg = driver.findElement(By.xpath("//*[@id=\"block-system-main\"]//p[1]"));
		String actualTitle = headerMsg.getText();
		
		if(actualTitle.equalsIgnoreCase(headerTitle)) {
			System.out.println("User is on Payment page");
		}
		
		else {
			System.out.println("User is on different page");
		}
		//Thread.sleep(3000);
	}
	
	
	@Test (priority= 41)
  public void AddCardDetails() throws InterruptedException {
	  
	  
		Thread.sleep(4000);
		
	
	  //WebElement cardNumber = driver.findElement(By.xpath("//*[@name=\"card_number\"]"));
		WebElement cardNumber = driver.findElement(By.xpath("//*[@class=\"card_number_iframe\"]"));
		setExplicitWait(cardNumber);
		//driver.switchTo().frame(cardNumber);
		
	  System.out.println("User is inside frame1");
	  cardNumber.click();
	  
	  cardNumber.sendKeys("5123456789012346");
	  
	 // driver.switchTo().parentFrame();
	  
	  
	  
	  //WebElement cardHolderName = driver.findElement(By.xpath("//*[@id=\"name_on_card\"]"));
	  WebElement cardHolderName = driver.findElement(By.xpath("//*[@class=\"name_on_card_iframe\"]"));
	  setExplicitWait(cardHolderName);
	  cardHolderName.click();
	  cardHolderName.sendKeys("demo test");
	  
      //WebElement cardexpMonth = driver.findElement(By.xpath("//*[@id=\"card_exp_month\"]"));
	  WebElement cardexpMonth = driver.findElement(By.xpath("//*[@class=\"card_exp_month_iframe\"]"));
	  setExplicitWait(cardexpMonth);
	  
      cardexpMonth.click();
      cardexpMonth.sendKeys("10");
      
      
      //WebElement cardExpYear = driver.findElement(By.xpath("//*[@id=\"card_exp_year\"]"));
      WebElement cardExpYear = driver.findElement(By.xpath("//*[@class=\"card_exp_year_iframe\"]"));
      setExplicitWait(cardExpYear);
      cardExpYear.click();
      cardExpYear.sendKeys("21");
	  
     //WebElement cvv = driver.findElement(By.xpath("//*[@id=\"security_code\"]"));
      WebElement cvv = driver.findElement(By.xpath("//*[@class=\"security_code_iframe\"]"));
      setExplicitWait(cvv);
      
     cvv.click();
     cvv.sendKeys("123");
     
     WebElement proceedButton = driver.findElement(By.xpath("//*[@id=\"edit-submit\"]"));
     proceedButton.click();
     
     Thread.sleep(15000);
     
     
  
	  
	  
  }
}
