package com.flower.TestCases.Flowers;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.flower.base.TestBase;
import com.flower.base.TestBase_newww;

public class HomeTestBase extends TestBase{
	
	 
		
	
	  
	
    //Method for selecting city from popup
	 
	  
	  @Test(priority =1)
	
	  
	  public void launchApplication() throws Exception {
		  
		 
		 setup();
		  
		  maximizeBrowser();
		  Thread.sleep(8000);
	  }
	  
	 
}

