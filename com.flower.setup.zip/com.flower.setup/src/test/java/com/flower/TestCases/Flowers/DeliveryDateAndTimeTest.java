package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.DeliveryDateAndTime;
import com.flower.base.TestBase;

public class DeliveryDateAndTimeTest extends TestBase {
	
	DeliveryDateAndTime dd = new DeliveryDateAndTime();
	
	
	
	@Test (priority= 180)
	  public void deliveryDate() throws InterruptedException {
		  
		  WebElement headerValidate = driver.findElement(By.xpath("//*[text()=\"Now Choose Delivery Date & Time\"]"));
		   dd.deliveryDateHeaderValidation(headerValidate);
		   
		   
		   WebElement date = driver.findElement(By.xpath("//*[@class=\"del-date-inner\"]//li[2]"));
		   //Calling tomorrow's date function
		   
		   dd.tomorrowDate(date);
		   
		   //Function for selecting delivery slot mode as standard delivery
		   
		   WebElement deliverySlotMode = driver.findElement(By.xpath("//*[@value=\"Standard Delivery\"]"));
		   WebElement deliverySlotTime = driver.findElement(By.xpath("//*[@class=\"fix-time-slot\"]//li[2]//input"));
		   
		   
		   dd.selectDeliverySlotMode(deliverySlotMode, deliverySlotTime);
		   
		   
		   
		   WebElement clickContinue = driver.findElement(By.xpath("//*[@value=\"Continue\"]"));
		   dd.clickContinueButton(clickContinue);
		   
		   
		   
		   //calling specialNote function
		   
		   specialNote();
		   		  
	  }
		
		
		//Function for validating special note
		
	@Test (priority= 181)
		public void specialNote() throws InterruptedException {
			WebElement validatingspecialNoteHeader = driver.findElement(By.xpath("//span[text()=\"Show extra affection ! \"]"));
			WebElement occassionSelect = driver.findElement(By.xpath("//*[@class=\"del-date-inner\"]//li[1]"));
			
			//Calling special note function from Page Action class
			
			dd.specialNote(validatingspecialNoteHeader, occassionSelect);
				
			//Clicking on Review button
			
			WebElement reviewBtn = driver.findElement(By.xpath("//*[@value=\"Review\"]"));
			
			dd.clickOnReview(reviewBtn);
			
			
			//Validate that user is on Next order Summary page
			
			WebElement orderSummaryTitle= driver.findElement(By.xpath("//span[text()=\"Order Summary\"]"));
			
			dd.validateOrderSummaryTitle(orderSummaryTitle);
			
			
		}
	
	       public void courierProductSelection() {
	    	   
	    	   WebElement courierText = driver.findElement(By.xpath("//*[text()=\"Courier Product\"]"));
	    	   WebElement courierSelectDate = driver.findElement(By.xpath("//*[text()=\"Select Date\"]"));
	    	   
	    	   
	    	   
	    	   
	       }
	
	}
