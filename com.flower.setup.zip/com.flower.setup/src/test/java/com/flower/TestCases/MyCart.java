package com.flower.TestCases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class MyCart extends TestBase {
	
	@Test (priority=12)
	public void validateMyCartPage() {
		
		 //test=extent.createTest("validateMyCartPage");
	WebElement cartSummary = driver.findElement(By.xpath("//div[text()=\"Cart Summary\"]"));
	  String welcomeHeader = cartSummary.getText();
	  
	  if(welcomeHeader.equalsIgnoreCase("Cart Summary")) {
		  System.out.println("User is on My Cart Page");
	  }
	  
	  
	  else {
		  System.out.println("User is on different page");	  }
	  
	  
	  
}
	//Validate the total of all products and their sum
	
	@Test (priority=14)
	public void sumTotalCart() {
		
		// test=extent.createTest("sumTotalCart");
		
		List<WebElement> cartValue = driver.findElements(By.xpath("//*[@class=\"head last\"]"));
		
		
		for(WebElement cartSum : cartValue) {
			String valueSum = cartSum.getText();
			int value = new Integer(valueSum).intValue();
			System.out.println("values are:::"+value);
			//calculate value of two integers
			
			int result = value;
			
			System.out.println("adding total of orders:::"+result);
		}
		
			WebElement totalSumOrder = driver.findElement(By.xpath("//*[@class=\"uc-price\"]"));
			String totalSumOrdervalue = totalSumOrder.getText();
			
			System.out.println("String value ::"+totalSumOrdervalue);
			
			//int totalValue= new Integer(totalSumOrdervalue).intValue();
			
			//System.out.println("Total value of order summary is:::"+totalValue);
			
			//validate the values...   not working.. check with Saurabh
			
			/*if(value.    otalValue) {
				
				System.out.println("order values are equal");
			}
			else {
				System.out.println("Mismatch in values");
			}*/
			
	}
          
	
	//Function for editing msg value
	
	@Test (priority=13)
	
	public void editMessage() throws InterruptedException {
		
		//test=extent.createTest("editMessage");
		
		Thread.sleep(2000);
		WebElement editButton = driver.findElement(By.xpath("//*[@class=\"edit-icon\"]"));
		editButton.click();
		
		//Write msg in textbox
		
		WebElement editmsg= driver.findElement(By.xpath("//*[@name=\"edit-message-input\"]"));
		editmsg.clear();
		editmsg.sendKeys("Happy Anniversary...");
		
		
		//Click on Update icon
		
		WebElement updateBtn = driver.findElement(By.xpath("//*[text()=\"Update\"]"));
		updateBtn.click();
		System.out.println("msg is updated");
		Thread.sleep(2000);
	}
	
	//Function for clicking on Place Order
	
	@Test (priority=15)	
	  public void clickOnPlaceOrder() {
		
		//test=extent.createTest("clickOnPlaceOrder");
		  
		  WebElement placeorderBtn = driver.findElement(By.xpath("//*[@value=\"Place order\"]"));
		  placeorderBtn.click();
		  System.out.println("User has clicked on Place Order button");
		  
	  }
	
	
}
