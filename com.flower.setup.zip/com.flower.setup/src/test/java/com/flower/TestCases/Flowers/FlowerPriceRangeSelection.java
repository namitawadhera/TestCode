package com.flower.TestCases.Flowers;

import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.flower.base.TestBase;

public class FlowerPriceRangeSelection extends TestBase {
	
	
  @Test (priority=100)
  public void PriceRangeSelection() throws InterruptedException {
	  
	  Thread.sleep(2000);
	  System.out.println("hello");
		 Actions actions = new Actions(driver);
		
		
		 WebElement flowerDelivery = driver.findElement(By.xpath("(//div//ul[@class='tb-megamenu-nav nav level-0 items-36']//li//a[text()='Flowers'])[2]"));
		 
		 
		 
		 
		 setExplicitWait(flowerDelivery);
		
		actions.moveToElement(flowerDelivery).build().perform();
		
		System.out.println("pass1");
		
		//Selecting any random price range from the list by calling random function from testBase class
		
		List<WebElement> priceSelect = driver.findElements(By.xpath("//*[contains(@href,'/flowers/price')]"));
		
		Thread.sleep(1000);
		

		 WebElement selectedPrice = getRandomElement(priceSelect);
		 String text = selectedPrice.getText();
		 Thread.sleep(1000);
		 System.out.println("Clicked on price range::::"+text);
		 selectedPrice.click();
			  
  }
}
