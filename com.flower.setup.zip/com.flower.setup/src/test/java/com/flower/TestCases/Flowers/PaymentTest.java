package com.flower.TestCases.Flowers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.PageActions.PaymentActions;
import com.flower.base.TestBase;

public class PaymentTest extends TestBase {
  
	PaymentActions pa = new PaymentActions();
	
	
	
	@Test (priority=195)
	public void paymentHeader() throws InterruptedException {
		
		WebElement headerMsg = driver.findElement(By.xpath("//*[@id=\"block-system-main\"]//p[1]"));
		pa.validatePaymentpageHeader(headerMsg);
	}
	
	
	@Test (priority=196)
  
  public void proceedPayBtn() throws InterruptedException {
		
		WebElement paymentButton = driver.findElement(By.xpath("//*[@id=\"edit-submit\"]"));
		
		pa.PAYU(paymentButton);
  }
}
