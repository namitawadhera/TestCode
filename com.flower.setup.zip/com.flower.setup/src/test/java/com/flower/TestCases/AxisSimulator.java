package com.flower.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class AxisSimulator extends TestBase {
  
	
	@Test (priority= 44)
  public void addPassword() throws InterruptedException {
	  
	  WebElement passwrd = driver.findElement(By.xpath("//*[@id=\"password\"]"));
	  setExplicitWait(passwrd);
	  passwrd.sendKeys("123456");
	  
	  WebElement payBtn = driver.findElement(By.xpath("//*[@id=\"submitBtn\"]"));
	  payBtn.click();
	  
	  Thread.sleep(5000);
	  
  }
	
	@Test (priority= 45)
	public void successMsg() {
		
		String expectedSuccessMsg ="Payment Success";
		
		WebElement actualMessage = driver.findElement(By.xpath("//*[@class=\"payment_success\"]"));
		
		String actualMsg = actualMessage.getText();
		
		if(expectedSuccessMsg.equalsIgnoreCase(actualMsg)) {
			
			System.out.println("User has successfully placed order");
		}
		
		else {
			System.out.println("Order is not placed. Kindly recheck");
		}
		
		
		WebElement orderid= driver.findElement(By.xpath("//*[@class=\"order_id\"]//span"));
		System.out.println("Order id of transaction is:::"+orderid.getText());
		
		WebElement amount= driver.findElement(By.xpath("//*[@class=\"trans_amount\"]//span"));
		System.out.println("Order id of transaction is:::"+amount.getText());
		
		
	}
}
