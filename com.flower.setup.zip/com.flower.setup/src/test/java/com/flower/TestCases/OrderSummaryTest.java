package com.flower.TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class OrderSummaryTest extends TestBase {
	
	
	@Test (priority= 35)
  public void validateCouponCode() throws InterruptedException {
	  
	  WebElement couponCode = driver.findElement(By.xpath("//*[@class=\"coupon-show-click\"]"));
	  couponCode.click();
	  
	  WebElement couponText = driver.findElement(By.xpath("//*[@id=\"coupon-wrap\"]"));
	  couponText.click();
	  couponText.clear();
	  couponText.sendKeys("FA10");
	  
	  //Click on Apply coupon link
	  
	  WebElement applyCoupon = driver.findElement(By.xpath("//*[@class=\"apply-link\"]"));
	  
	  applyCoupon.click();
	  Thread.sleep(2000);
  }
	
	
	@Test (priority= 36)
  
  public void proceedToPayment() throws InterruptedException {
	  
	  WebElement paymentBtn = driver.findElement(By.xpath("//input[@name=\"Proceed to payment\"]"));
	  paymentBtn.click();
	  Thread.sleep(2000);
	  
  }
}
