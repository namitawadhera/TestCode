package com.flower.TestCases.Flowers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.flower.base.TestBase;

public class MyCart extends TestBase {
	
	@Test (priority=150)
	public void validateMyCartPageHeader() {
		
		 
	WebElement cartSummary = driver.findElement(By.xpath("//div[text()=\"Cart Summary\"]"));
	
	
	validateMyCartPage(cartSummary);
	
	}
	
	
	
	
	//Validate the total of all products and their sum
	
	@Test (priority=151)
	public void sumTotalCart() {
		

		
		List<WebElement> cartValue = driver.findElements(By.xpath("//*[@class=\"head last\"]"));
		
		
		for(WebElement cartSum : cartValue) {
			String valueSum = cartSum.getText();
			int value = new Integer(valueSum).intValue();
			System.out.println("values are:::"+value);
			//calculate value of two integers
			
			int result = value;
			
			System.out.println("adding total of orders:::"+result);
		}
		
			WebElement totalSumOrder = driver.findElement(By.xpath("//*[@class=\"uc-price\"]"));
			String totalSumOrdervalue = totalSumOrder.getText();
			
			System.out.println("String value ::"+totalSumOrdervalue);
			
			
			
	}
          
	
	//Function for editing msg value
	
	@Test (priority=152)
	
	public void editMessage() throws InterruptedException {
		
		//test=extent.createTest("editMessage");
		
		Thread.sleep(2000);
		WebElement editButton = driver.findElement(By.xpath("//*[@class=\"edit-icon\"]"));
		
		//Write msg in textbox
		
		WebElement editmsg= driver.findElement(By.xpath("//*[@name=\"edit-message-input\"]"));
		
		//Click on Update icon
		
		WebElement updateBtn = driver.findElement(By.xpath("//*[text()=\"Update\"]"));
		
		
		messageEdit(editButton,editmsg,updateBtn);
	}
	
	//Function for clicking on Place Order
	
	@Test (priority=153)	
	  public void clickOnPlaceOrder() throws InterruptedException {
		
		  
		  WebElement placeorderBtn = driver.findElement(By.xpath("//*[@value=\"Place order\"]"));
		  placeorderBtn.click();
		  System.out.println("User has clicked on Place Order button");
		  Thread.sleep(3000);
		  
	  }
	
	
}
